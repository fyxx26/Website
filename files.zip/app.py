from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = 'kasir_fikri_secret'

def format_rupiah(val):
    return "Rp{:,.0f}".format(val).replace(",", ".")

@app.route("/", methods=["GET", "POST"])
def index():
    if "items" not in session:
        session["items"] = []
    if "riwayat" not in session:
        session["riwayat"] = []

    struk = None
    kembalian = None
    total = sum(item["harga"] * item["jumlah"] for item in session["items"])

    if request.method == "POST":
        if "tambah" in request.form:
            try:
                nama = request.form["nama_barang"]
                harga = float(request.form["harga"])
                jumlah = int(request.form["jumlah"])
                session["items"].append({
                    "nama": nama,
                    "harga": harga,
                    "jumlah": jumlah
                })
                session.modified = True
            except:
                flash("Harga dan jumlah harus berupa angka!", "danger")
        elif "proses" in request.form:
            try:
                bayar = float(request.form["bayar"])
                if bayar < total:
                    flash("Uang tidak cukup!", "warning")
                else:
                    kembalian = bayar - total
                    waktu = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    no_struk = f"TRX{random.randint(1000,9999)}"
                    # Simpan riwayat
                    session["riwayat"].append({
                        'waktu': waktu,
                        'no_struk': no_struk,
                        'total': total,
                        'bayar': bayar,
                        'kembalian': kembalian,
                        'items': list(session["items"])
                    })
                    session.modified = True
                    # Tampilkan struk
                    struk = {
                        'no_struk': no_struk,
                        'waktu': waktu,
                        'items': list(session["items"]),
                        'total': total,
                        'bayar': bayar,
                        'kembalian': kembalian
                    }
                    session["items"] = []
            except:
                flash("Masukkan jumlah uang bayar yang valid.", "danger")

    return render_template(
        "index.html",
        items=session["items"],
        total=total,
        format_rupiah=format_rupiah,
        struk=struk
    )

@app.route("/riwayat")
def riwayat():
    riwayat = session.get("riwayat", [])
    return render_template("riwayat.html", riwayat=riwayat, format_rupiah=format_rupiah)

@app.route("/refresh")
def refresh():
    session["items"] = []
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)